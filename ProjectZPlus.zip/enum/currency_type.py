from enum import Enum


class CurrencyType(Enum):
    COINS = 100
    MERCH = 101
    DIAMONDS = 103
