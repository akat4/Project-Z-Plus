from enum import Enum


class PartyQueryType(Enum):
    ALL = 0
    ONLINE = 1
