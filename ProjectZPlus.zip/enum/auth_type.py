from enum import Enum


class AuthType(Enum):
    EMAIL = 1
    PHONE_NUMBER = 2
    SECRET = 5
