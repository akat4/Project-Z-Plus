from enum import Enum


class Gender(Enum):
    MALE = 1
    FEMALE = 2
    OTHER = 100
