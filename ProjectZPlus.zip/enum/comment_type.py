from enum import Enum


class CommentType(Enum):
    TEXT = 1
    MEDIA = 2
