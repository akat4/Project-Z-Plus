from enum import Enum


class CircleMembersQueryType(Enum):
    NORMAL = "normal"
    BLOCKED = "blocked"
